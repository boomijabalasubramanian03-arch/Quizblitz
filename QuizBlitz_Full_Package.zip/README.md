# QuizBlitz — Full Package

This package contains everything needed to run QuizBlitz end-to-end: a single-file
frontend (HTML/CSS/JS) and a Node.js + Express + MongoDB backend.

```
QuizBlitz_package/
├── frontend/
│   └── QuizBlitz.html        ← The entire app UI (open this in a browser)
├── backend/
│   ├── server.js             ← Express entry point
│   ├── package.json
│   ├── .env.example          ← Copy to .env and fill in your values
│   ├── seedAdmin.js          ← Creates the default login (run once)
│   ├── models/
│   │   ├── Quiz.js
│   │   ├── Submission.js
│   │   └── User.js
│   └── routes/
│       ├── authRoutes.js
│       ├── quizRoutes.js
│       └── submissionRoutes.js
└── README.md                 ← You are here
```

## Two ways to use this

### Option A — Just open the HTML file (no backend, works immediately)
Double-click `frontend/QuizBlitz.html` (or open it in any browser). Everything —
quiz creation, playing, scoreboard, certificates — works fully using your
browser's local storage. No setup required. This is the fastest way to try it
out or to use it for a single device/classroom.

### Option B — Connect it to the real database (multi-device, persistent)
This lets quizzes and scores sync across every device, stored in MongoDB.

**1. Install backend dependencies**
```bash
cd backend
npm install
```

**2. Configure your environment**
```bash
cp .env.example .env
```
Open `.env` and fill in:
- `MONGO_URI` — your MongoDB connection string (a free [MongoDB Atlas](https://www.mongodb.com/cloud/atlas/register) cluster works great, or a local MongoDB install)
- `JWT_SECRET` — any long random string (the `.env.example` file shows a command to generate one)

**3. Create the default login**

This creates the `admin@quizblitz.app` / `quizblitz2024` account in your database
so you can log in right away (you can change these later from QuizBlitz → Settings).
```bash
npm run seed
```

**4. Start the server**
```bash
npm start
```
You should see:
```
✅ Connected to MongoDB
✅ QuizBlitz API listening on http://localhost:5000
```

**5. Connect the frontend to it**

Open `frontend/QuizBlitz.html` in your browser. Click the **🔌 Local** badge in the
top-right corner (or go to Creator Dashboard → Settings → Backend Configuration),
paste in your backend URL (e.g. `http://localhost:5000`), and click **Test & Connect**.
The badge will turn into **☁️ Cloud** once it's connected.

From then on, every quiz you create and every score submitted is saved to MongoDB
instead of just the browser — so it's visible from any device that connects to the
same backend URL.

## Deploying so it's accessible from anywhere

- **Backend**: deploy the `backend/` folder to a host like Render, Railway, or
  Fly.io (all have free tiers). Set the same `MONGO_URI` and `JWT_SECRET`
  environment variables there. You'll get a public URL like
  `https://quizblitz-api.onrender.com`.
- **Frontend**: open `frontend/QuizBlitz.html`, go to Creator Dashboard →
  Quiz Builder → Launch tab, and click **⬇ Download**, then drag the file onto
  [netlify.com/drop](https://app.netlify.com/drop) for an instant public link —
  or just host the single HTML file anywhere static files are served.
- Once both are live, open the deployed frontend and connect it to your deployed
  backend URL the same way as step 5 above.

## Default login

| Field | Value |
|---|---|
| Email | `admin@quizblitz.app` |
| Password | `quizblitz2024` |

Change these any time from **Creator Dashboard → Settings → Change Login Credentials**.
Note: if you're using local-only mode (Option A), credential changes are stored in
your browser. If connected to the backend (Option B), update the password in the
database as well by re-running a custom seed, or rebuild this with profile-update
support if you need that later.

## What the app can do

- **Quiz Builder** — multiple choice, true/false, short answer, and opinion-poll
  questions, with per-question points, difficulty, and timers
- **Behaviour options** — shuffle questions, show answers after each question,
  streak bonuses, one-attempt-per-email, allow skipping, certificates for all
- **Player experience** — animated timers, streak tracking, point bursts, instant
  feedback, progress bar
- **Scoreboard** — live leaderboard, CSV export, per-quiz filtering
- **Certificates** — fully customizable (colors, text, signer, score ring), with
  print-to-PDF download
- **8 visual themes** — Dark, Ocean, Forest, Candy, Cosmic, Solar, Teal, Ruby
- **Sharing** — WhatsApp and email share, copyable quiz links
- **Notifications** — live alerts when players join or finish a quiz
- **Backend sync** — optional real-time connection to your MongoDB database, with
  automatic fallback to local storage if the backend is unreachable

## Troubleshooting

- **"Connection failed" when testing the backend URL** — make sure the backend
  is running (`npm start`) and that the URL doesn't have a trailing slash. If
  you deployed it remotely, check that CORS isn't being blocked by your host's
  firewall settings.
- **Login fails even with the right password** — run `npm run seed` to make
  sure the default user actually exists in your database.
- **MongoDB connection errors on startup** — double check your `MONGO_URI` in
  `.env`. For MongoDB Atlas, make sure your IP address is allow-listed under
  Network Access in the Atlas dashboard.
