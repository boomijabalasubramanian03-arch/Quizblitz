const mongoose = require("mongoose");

const questionSchema = new mongoose.Schema({
  type: String,
  question: String,
  options: [String],
  correctAnswer: String,
  points: { type: Number, default: 1 },
  difficulty: { type: String, default: "easy" }
});

const quizSchema = new mongoose.Schema({
  title: String,
  category: String,
  description: String,
  passScore: Number,
  questions: [questionSchema],
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" }
}, { timestamps: true });

module.exports = mongoose.model("Quiz", quizSchema);