const mongoose = require("mongoose");

const submissionSchema = new mongoose.Schema({
  studentName: String,
  email: String,
  field: String,
  quizId: { type: mongoose.Schema.Types.ObjectId, ref: "Quiz" },
  score: Number,
  totalQuestions: Number
}, { timestamps: true });

module.exports = mongoose.model("Submission", submissionSchema);