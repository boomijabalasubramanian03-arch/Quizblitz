const express = require("express");
const Quiz = require("../models/Quiz");

const router = express.Router();

router.post("/", async (req, res) => {
  const quiz = await Quiz.create(req.body);
  res.status(201).json(quiz);
});

router.get("/", async (req, res) => {
  const quizzes = await Quiz.find().sort({ createdAt: -1 });
  res.json(quizzes);
});

router.get("/:id", async (req, res) => {
  const quiz = await Quiz.findById(req.params.id);
  res.json(quiz);
});

module.exports = router;