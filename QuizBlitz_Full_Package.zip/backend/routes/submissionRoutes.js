const express = require("express");
const Submission = require("../models/Submission");

const router = express.Router();

router.post("/", async (req, res) => {
  const submission = await Submission.create(req.body);
  res.status(201).json(submission);
});

router.get("/", async (req, res) => {
  const data = await Submission.find().populate("quizId");
  res.json(data);
});

module.exports = router;