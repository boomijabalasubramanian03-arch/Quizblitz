require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const authRoutes = require("./routes/authRoutes");
const quizRoutes = require("./routes/quizRoutes");
const submissionRoutes = require("./routes/submissionRoutes");

const app = express();

// Allow the QuizBlitz frontend (or any origin) to call this API.
// If you want to lock this down later, replace true with your frontend's URL.
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());

// Simple request log — helpful while you're testing the connection
app.use((req, _res, next) => {
  console.log(`${req.method} ${req.path}`);
  next();
});

app.use("/api/auth", authRoutes);
app.use("/api/quizzes", quizRoutes);
app.use("/api/submissions", submissionRoutes);

// Health check — QuizBlitz pings this on the same route as GET /api/quizzes,
// but this root route is handy for a quick manual check in the browser.
app.get("/", (_req, res) => {
  res.json({ status: "QuizBlitz API is running" });
});

const PORT = process.env.PORT || 5000;
const MONGO_URI = process.env.MONGO_URI;

if (!MONGO_URI) {
  console.error("\n❌ Missing MONGO_URI in your .env file.");
  console.error("   Copy .env.example to .env and fill in your MongoDB connection string.\n");
  process.exit(1);
}

mongoose
  .connect(MONGO_URI)
  .then(() => {
    console.log("✅ Connected to MongoDB");
    app.listen(PORT, () => {
      console.log(`✅ QuizBlitz API listening on http://localhost:${PORT}`);
      console.log(`   Paste this URL into the QuizBlitz "Backend Connection" modal.`);
    });
  })
  .catch((err) => {
    console.error("❌ MongoDB connection failed:", err.message);
    process.exit(1);
  });
