// One-time setup script: creates the default creator account
// (admin@quizblitz.app / quizblitz2024) so the "Backend Connection"
// login in QuizBlitz works immediately against your database.
//
// Run with:  npm run seed
// (You can change the email/password below before running it,
//  or just change them later in QuizBlitz's Settings tab.)

require("dotenv").config();
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const User = require("./models/User");

const DEFAULT_EMAIL = "admin@quizblitz.app";
const DEFAULT_PASSWORD = "quizblitz2024";

async function seed() {
  if (!process.env.MONGO_URI) {
    console.error("❌ Missing MONGO_URI in your .env file. Copy .env.example to .env first.");
    process.exit(1);
  }

  await mongoose.connect(process.env.MONGO_URI);
  console.log("✅ Connected to MongoDB");

  const existing = await User.findOne({ email: DEFAULT_EMAIL });
  if (existing) {
    console.log(`ℹ️  User ${DEFAULT_EMAIL} already exists — nothing to do.`);
  } else {
    const hashed = await bcrypt.hash(DEFAULT_PASSWORD, 10);
    await User.create({ email: DEFAULT_EMAIL, password: hashed, role: "creator" });
    console.log(`✅ Created default creator account:`);
    console.log(`   Email:    ${DEFAULT_EMAIL}`);
    console.log(`   Password: ${DEFAULT_PASSWORD}`);
    console.log(`   (You can change these later from QuizBlitz → Settings)`);
  }

  await mongoose.disconnect();
  process.exit(0);
}

seed().catch((err) => {
  console.error("❌ Seeding failed:", err.message);
  process.exit(1);
});
